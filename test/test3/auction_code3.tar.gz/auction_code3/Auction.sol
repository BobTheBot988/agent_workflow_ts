// SPDX-License-Identifier: GPL-3.0 or above
pragma solidity 0.8.34;
contract Auction {
  address private owner;
  NFT private auctionedToken;
  ERC20 public token;
  ERC721 public collection;
  struct NFT {
    uint256 tokenId;
  }
  constructor (ERC721 _collection, uint256 tokenId, address _owner) public {
  }
  function bid (uint256 amount) public payable {
  }
  function getWinner () public payable returns (address) {
  }
}
