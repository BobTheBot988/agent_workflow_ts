// SPDX-License-Identifier: GPL-3.0 or above
pragma solidity 0.8.34;
interface ERC165 {
  function supportInterface (byte4 interfaceID) external view returns (bool);
}
